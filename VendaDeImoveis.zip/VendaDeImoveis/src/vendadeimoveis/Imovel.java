/*
 *Pedro H. G. Cangemi
 *Código: 830934
 */
package vendadeimoveis;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Pedro
 */
public class Imovel {

    enum Categorias {comercial, residencial};
    enum Tipos {Apartamento,Casa,Chácara,Sala,Salão,Sítio}; 
    private Categorias categoria;
    private Tipos tipo;
    private String nome;
    private String Descricao;
    private Double valorVenda;

    public Imovel(String nome, String Descricao, Double valorVenda,Categorias categoria, Tipos tipo) {
        this.nome = nome;
        this.Descricao = Descricao;
        this.valorVenda = valorVenda;
        this.categoria = categoria;
        this.tipo = tipo;
        
    }

   public Categorias getCategoria() {
        return categoria;
    }


    public Tipos getTipo() {
        return tipo;
    }
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return Descricao;
    }

    public void setDescricao(String Descricao) {
        this.Descricao = Descricao;
    }

    public Double getValorVenda() {
        return valorVenda;
    }

    public void setValorVenda(double valorVenda) {
        this.valorVenda = valorVenda;
    }
    
    public String getValorString(){
        return this.valorVenda.toString();
    }
    
    
}
